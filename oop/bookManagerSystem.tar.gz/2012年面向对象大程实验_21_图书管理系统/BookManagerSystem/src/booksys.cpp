#include "booksys.h"

booksys::booksys()
{
    u_id = "";
    u_pw = "";
    super_user = false;
    logined = false;
    func_id = 0;
    exit_flag = false;
}

booksys::~booksys()
{
}

void booksys::run()
{
    while(!logined)
    {
        welcome();
        login();
        while(logined && !exit_flag){
        func_choose();
        function();
        }
        if(exit_flag)
            break;
    }
}


void booksys::welcome()
{
    cout << "This is Book Manage System!" << endl
        << "Welcome!" << endl;
}

void booksys::login()
{
    bool valid = false;
    while(!valid){
        cout << "Your Name: ";
        //cin.getline(temp,100);
        //u_id = temp;
        cin >> u_id;

        /* 回显问题需要解决 */
        cout << "Password: ";
        //cin.getline(temp,100);
        //u_pw = temp;
        cin >> u_pw;

        cout << endl;
        //cout << u_id.c_str();

        person temp = p_io.find(u_id.c_str());
        if(strcmp(temp.getpwd(), u_pw.c_str()) == 0){
            valid = true;
            cout << "login succeed!   Welcome back " << u_id << endl;
            cout << endl;
            if(temp.getadmin()){
                super_user = true;
            }
            else{
                super_user = false;
            }
            logined = true;
        }
        else{
            cout << "login invalid" << endl;
            cout << endl;
        }
    }
}

void booksys::func_choose()
{
    bool valid = false;
    while(!valid){
        cout << "1.Search Book\t2.Show Borrow Record" << endl;
        if(super_user)
        {
            cout << "3.Add Book\t4.Delete Book\t5.Add User\t6.Delete User" << endl;
            cout << "7.Borrow Book\t8.Return Book\t" << endl;
        }
        cout << "9.Logout\t0.Exit" << endl;
        cout << "What's your Choice ?";
        cin >> func_id;
        if(!super_user && ((func_id <= 2 && func_id >= 1) || func_id == 9 || func_id == 0))
            valid = true;
        else if(super_user && func_id <= 9 && func_id >= 0)
            valid = true;
    }
}

void booksys::function()
{
    switch(func_id)
    {
        case 1:
            search_book();
            break;
        case 2:
            borrowed_book();
            break;
        case 3:
            add_book();
            break;
        case 4:
            del_book();
            break;
        case 5:
            add_user();
            break;
        case 6:
            del_user();
            break;
        case 7:
            borrow_book();
            break;
        case 8:
            return_book();
            break;
        case 9:
            logout();break;
        case 0:
            exit_all();break;
        default:break;
    }
    cout << endl;
}

void booksys::search_book()
{
    string attr[] = {"BookID", "Category", "BookName", "Press",
            "Year", "Author", "Price", "TotalNum", "Inventory"};
    int attr_id = 0;
    string value;
    int from_int, to_int;
    double from_double, to_double;
    b_io.select("BookID","\0",true);
    getline(cin, value);
    while(attr_id <= 8){
        cout << attr[attr_id] << "?" << endl;
        if((attr_id>= 0 && attr_id <= 3) || (attr_id == 5)){
            getline(cin, value);
            //cin >> value;
            b_io.select(attr[attr_id], value.c_str(), false);
        }
        else if(attr_id == 4 || attr_id == 7 || attr_id == 8){
            cout << "enter the lower bound and upper bound in two lines:" << endl;
            getline(cin, value);
            if(value == ""){
                attr_id++;
                continue;
            }
            else
            {
                from_int = atoi(value.c_str());
            }
            cin >> to_int;
            b_io.select(attr[attr_id], from_int, to_int, false);
            getline(cin, value);
        }
        else if(attr_id == 6){
            cout << "enter the lower bound and upper bound in two lines:" << endl;
            getline(cin, value);
            if(value == ""){
                attr_id++;
                continue;
            }
            else
            {
                from_double = atof(value.c_str());
            }
            cin >> to_double;
            b_io.select(attr[attr_id], from_double, to_double, false);
            getline(cin, value);
        }
        attr_id++;
    }
    b_io.print_sel();
}

// Have some problems
void booksys::add_user()
{
    string user;
    string passwd;
    int card_id;
    int limit; bool admin;
    cout << "username?" << endl;
    cin >> user;
    cout << "password?" << endl;
    cin >> passwd;
    cout << "card id?" << endl;
    cin >> card_id;
    cout << "borrow book limitation?" << endl;
    cin >> limit;
    cout << "admin user?" << endl;
    cin >> admin;
    p_io.insert(person(user.c_str(), passwd.c_str(), card_id, limit, 0, admin));
}

// Have some problems
void booksys::del_user()
{
    string user;
    int id;
    cout << "username" << endl;
    cin >> user;
    //cout << "card id?" << endl;
    //cin >> id;

    cout << p_io.deleted(user.c_str()) << endl;
    //cout << p_io.deleted(id) << endl;
}

void booksys::add_book()
{
    string attr[] = {"BookID", "Category", "BookName", "Press",
            "Year", "Author", "Price", "TotalNum", "Inventory"};
    int attr_id = 0;
    string BookID, Category, BookName, Press, Author;
    int Year;
    int TotalNum;
    double Price;
    cout << attr[attr_id++] << "?" << endl;
    cin >> BookID;
    if(!b_io.select("BookID", BookID.c_str(), true))
    {
        cout << attr[attr_id++] << "?" << endl;
        cin >> Category;
        cout << attr[attr_id++] << "?" << endl;
        cin >> BookName;
        cout << attr[attr_id++] << "?" << endl;
        cin >> Press;
        cout << attr[attr_id++] << "?" << endl;
        cin >> Year;
        cout << attr[attr_id++] << "?" << endl;
        cin >> Author;
        cout << attr[attr_id++] << "?" << endl;
        cin >> Price;
        cout << attr[attr_id++] << "?" << endl;
        cin >> TotalNum;
        b_io.insert(BookID.c_str(), Category.c_str(), BookName.c_str(),
        Press.c_str(), Year, Author.c_str(), Price, TotalNum, TotalNum);
    }
    else{
        cout << "TotalNum?" << endl;
        cin >> TotalNum;
        b_io.update(BookID.c_str(),"TotalNum", TotalNum+b_io.get_TotalNum(BookID.c_str()));
        b_io.update(BookID.c_str(),"Inventory", TotalNum+b_io.get_Inventory(BookID.c_str()));
    }
}

void booksys::del_book()
{
    string BookID;
    cout << "book id?" << endl;
    cin >> BookID;
    b_io.del(BookID.c_str());
}

void booksys::borrow_book()
{
    int year, month, day, hour, minute, second;
    string book_id;
    string user_id;
    string pwd;
    cout << "book id?" << endl;
    cin >> book_id;
    cout << "username?" << endl;
    cin >> user_id;
    cout << "password?" << endl;
    cin >> pwd;
    cout << "borrow time? (YYYY MM DD HH MM SS)" << endl;
    cin >> year >> month >> day >> hour >> minute >> second;
    datetime b_time = datetime(year, month, day, hour, minute, second);
    cout << "return time? (YYYY MM DD HH MM SS)" << endl;
    cin >> year >> month >> day >> hour >> minute >> second;
    datetime r_time = datetime(year, month, day, hour, minute, second);
    if(p_io.find(user_id.c_str(), pwd.c_str()) &&
            (b_io.select("BookID", book_id.c_str(), true) > 0) &&
            b_io.get_Inventory(book_id.c_str()) > 0)
    {
        person temp = p_io.find(user_id.c_str());
        if(temp.getborrowed() < temp.getlimit()){
            r_io.append(book_id, user_id, u_id, b_time, r_time);
            b_io.update(book_id.c_str(), "Inventory",
                b_io.get_Inventory(book_id.c_str())-1);
            person new_p = person(temp.getaccount(), temp.getpwd(),
                    temp.getid(), temp.getlimit(), temp.getborrowed()+1,
                    temp.getadmin());
            p_io.change(user_id.c_str(), new_p);
        }
    }
    else
        cout << "Cannot borrow!" << endl;
}

void booksys::return_book()
{
    string book_id;
    string user_id;
    cout << "book id?" << endl;
    cin >> book_id;
    cout << "username?" << endl;
    cin >> user_id;
    if(r_io.filter(book_id, user_id)){
        r_io.del(book_id, user_id);
        b_io.update(book_id.c_str(), "Inventory",
            b_io.get_Inventory(book_id.c_str())+1);
        person temp = p_io.find(user_id.c_str());
        person new_p = person(temp.getaccount(), temp.getpwd(),
                temp.getid(), temp.getlimit(), temp.getborrowed()-1,
                temp.getadmin());
        p_io.change(user_id.c_str(), new_p);
    }
}

void booksys::borrowed_book()
{
    string user_id;
    cout << "username?" << endl;
    cin >> user_id;
    r_io.filter(user_id);
}

void booksys::logout()
{
    logined = false;
    cout << endl;
}

void booksys::exit_all()
{
    exit_flag = true;
}
