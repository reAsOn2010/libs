#ifndef _DATETIME_H_
#define _DATETIME_H_

#include<string>
#include<cstdio>
class datetime
{
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
public:
    bool check(int, int, int, int, int, int)const;
    datetime();
    datetime(int, int, int, int, int, int);
    ~datetime();
    int compare(const datetime &)const;
    void update(int, int, int, int, int , int);
    std::string to_string()const;
    bool operator>(const datetime &)const;
    bool operator<(const datetime &)const;
    bool operator==(const datetime &)const;
};

class datetime_error
{
public:
    datetime_error(){};
    void print(){
        printf("datetime error!\n");
    }
};

#endif
