#include"datetime.h"

datetime::datetime(){
    year = month = day = hour = minute = second = 0;
}

datetime::datetime(int year, int month, int day, int hour, int minute, int second)
{
    if(check(year, month, day, hour, minute, second)){
        this->year = year;
        this->month = month;
        this->day = day;
        this->hour = hour;
        this->minute = minute;
        this->second = second;
    }
    else{
        throw datetime_error();
    }
}
datetime::~datetime(){}

bool datetime::check(int year, int month, int day, int hour, int minute, int second)const
{
    int valid_day[][13] = {{0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
    {0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}};
    bool ret = true;
    bool leap = false;
    if(year >=2012)
        ret = false;
    if(year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))
        leap = true;
    if(month <=0 || month >=13)
        ret = false;
    if(day <= 0 || day > valid_day[leap][month])
        ret = false;
    if(hour < 0 || hour > 23)
        ret = false;
    if(minute < 0 || minute > 59)
        ret = false;
    if(second < 0 || second > 59)
        ret = false;
    return ret;
}

int datetime::compare(const datetime &other)const
{
    int cmp[6];
    cmp[0] = year - other.year;
    cmp[1] = month - other.month;
    cmp[2] = day - other.day;
    cmp[3] = hour - other.hour;
    cmp[4] = minute - other.minute;
    cmp[5] = second - other.second;

    for(int i = 0; i < 6; i++){
        if(cmp[i] != 0)
            return cmp[i];
    }
    return 0;
}

std::string datetime::to_string()const
{
    char temp[20];
    sprintf(temp,"%d/%d/%d %d:%d:%d", year, month, day, hour, minute, second);
    std::string ret(temp);
    return ret;
}

void datetime::update(int year, int month, int day, int hour, int minute, int second)
{
    if(check(year, month, day, hour, minute, second)){
        this->year = year;
        this->month = month;
        this->day = day;
        this->hour = hour;
        this->minute = minute;
        this->second = second;
    }
    else{
        throw datetime_error();
    }
}

bool datetime::operator>(const datetime & other)const
{
    return this->compare(other) > 0? true : false;
}
bool datetime::operator<(const datetime & other)const
{
    return this->compare(other) < 0? true : false;
}
bool datetime::operator==(const datetime & other)const
{
    return this->compare(other) == 0? true : false;
}

