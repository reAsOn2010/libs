#include<fstream>
#include<iostream>
#include"c_person.h"
using namespace std;
	person::person()
	{
		id = 0;
		limit = 3;
		admin = false;
		borrowed = 0;
	}
	person::person(const char a[], const char b[])
	{
		id = 0;
		limit = 3;
		admin = false;
		borrowed = 0;
		strcpy(account,a);
		strcpy(pwd,b);
	}
	person::person(const char a[],const char b[], unsigned int c, int d, int f,bool g)
	{
		id = c;
		limit = d;
		admin = g;
		borrowed = f;
		strcpy(account,a);
		strcpy(pwd,b);
	}

