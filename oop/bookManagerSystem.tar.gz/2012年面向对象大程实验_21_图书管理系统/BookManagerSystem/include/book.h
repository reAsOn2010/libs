#include <fstream>
#include <iostream>
#include <string>
#include <cstring>


using namespace std;
struct book_info
{
    char BookID[11];
    char Category[21];
    char BookName[51];
    char Press[51];
    unsigned int Year;
    char Author[51];
    double Price;
    unsigned int TotalNum;
    unsigned int Inventory;
    char Picture[46];
};

class book_io
{
    book_info *book;
    
private:
    void copy(const char *, const char *) const;
    void clear(char *) const;
public:
    book_io();
    ~book_io();
    //select overload
    //input: attribute, value, new_flag
    //return value: the number of selected tuples
    int select(string, const char *, bool = false) const;//for string value
    //input: attribute, lower_bound, upper_bound, new_flag
    int select(string, int = 0, int = 32767, bool = false) const;//for int value
    int select(string, double = 0.0, double = 99999.9, bool = false) const;//for double value
    //print the result of last selection
    void print_sel() const;
    //print picture
    bool print_pic(const char *) const;
    //insert
    //input: bookid, category, bookname, press, year, author, price, totalnum, inventory
    bool insert(const char *, const char *, const char *, const char *, int, const char *, double, int, int, const char * = ".\\Picture\\default.jpg") const;
    //delete (only for primary key)
    //input: bookid
    bool del(const char *) const;
    //update (select only for primary key)  overload
    //input: bookid, attribute, new_value
    bool update(const char *, string, const char *) const;//for string value
    bool update(const char *, string, int) const;//for int value
    bool update(const char *, string, double) const;//for double value
    
    //get (only for primary key)
    char* get_Category(const char *) const;//for string value
    char* get_BookName(const char *) const;
    char* get_Press(const char *) const;
    char* get_Author(const char *) const;
    char* get_Picture(const char *) const;
    int get_Year(const char *) const;//for int value 
    int get_Inventory(const char *) const;
    int get_TotalNum(const char *) const;
    double get_Price(const char *) const;//for double value
    
};


