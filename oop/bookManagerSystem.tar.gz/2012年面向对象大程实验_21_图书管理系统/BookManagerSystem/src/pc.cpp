#include<fstream>
#include<iostream>
#include"pc.h"
using namespace std;
pc::pc(bool ad)
{
	fstream os;
os.open("./data/person.dat",ios_base::in|ios_base::out|ios_base::binary);	
	person p;

	while(!os.eof())
	{
		os>>p;
		if(p.getlimit() == -1 || strlen(p.getaccount())==0)break;
		if(p.getadmin() == ad)
			pl.insert(p);
	}
}



pc::pc()
{
	fstream os;
os.open("./data/person.dat",ios_base::in|ios_base::out|ios_base::binary);	
	person p;

	while(!os.eof())
	{
		os>>p;
		
		if(p.getlimit() == -1 || strlen(p.getaccount())==0){break;}
		
		//cout<<p.getaccount()<<endl;
			pl.insert(p);
	}
}





void pc::save()
{
	pl.print();
}


bool pc::insert(person data)
{
	if((pl.find(data.getaccount()) != -1) || (pl.find(data.getid()) != -1)) {cout<<"youle"<<endl;return false;}//���ҵ���ͬ��Ϣ�򷵻��ظ��ź�
	pl.insert(data);
	save();
	return true;
}


bool pc::deleted(int id)
{
	fstream os;
os.open("./data/person.dat",ios_base::in|ios_base::out|ios_base::binary);
	int pos;
	pos = pl.find(id);
	if(pos == -1){cout<<"meiyou"<<endl;return false;}//��û���ҵ����򷵻�û�п�ɾ���Ķ���
	pl.deleted(pos);
	save();
	os<<endl;
	return true;
}

bool pc::deleted(const char account[])
{
	int pos;
	pos = pl.find(account);
	if(pos == -1)
	{
		cout<<"meiyou"<<endl;
		return false;
	}
	else
	{
		pl.deleted(pos);
		save();
		return true;
	}
}

void pc::print()
{
	pl.print1();
}


bool pc::change(const char account[], person data)
{
	int pos = pl.find(account);
	if(pos == -1) 
	{
		return false;
	}
	//if(pl.find(data.getaccount()) != -1) {cout<<"youle"<<endl;return false;}//���ҵ���ͬ��Ϣ�򷵻��ظ��ź�
		bool f = pl.change(pos, data);
		save();
		return f;
}

person pc::find(const char account[])
{
	int pos;
	pos = pl.find(account);
	return (pl.findp(pos));
}
bool pc::find(const char account[],const char pwd[])
{
	int pos;
	pos = pl.find(account, pwd);
	if(pos == -1) return false;
	else return true;
}
