#include "book.h"

book_io::book_io()
{
    book = new book_info;
}

book_io::~book_io()
{
    delete book;
}

//copy sour to dist
void book_io::copy(const char *dist, const char *sour) const
{
    char ch;
    ifstream fin(sour, ios_base::binary);
    ofstream fout(dist, ios_base::binary);
    while(fin.get(ch))
    {
        fout << ch;
    }
    fin.close();
    fout.close();
}

//clear file
void book_io::clear(char *file) const
{
    ofstream fout(file, ios_base::binary);
    fout.close();
}

//select
//for string value
int book_io::select(string attr, const char *sel_value, bool new_flag) const
{
    int index, count = 0;
    bool sel_flag;
    ifstream fin;
    ofstream fout("./data/book_temp.dat", ios_base::binary);
    //generate a string-type table
    string Table[6] = {"BookID", "Category", "BookName", "Press", "Author","Picture"};
    //get index
    for(index = 0; index < 6; index++)
    {
        if(attr == Table[index]) break;
    }
    if(index == 6)
    {
        cout << "ERROR: No such attribute!" << endl;
        return 0;
    }
     //if start a new select
    if(new_flag)
    {
        this->copy("./data/book_sel.dat", "./data/book.dat");
    }
    fin.open("./data/book_sel.dat", ios_base::binary);

    while(fin.read((char *)book, sizeof(*book)))
    {
        sel_flag = false;
        switch(index)
        {
            case 0: if(strstr((*book).BookID, sel_value))
                    {
                        sel_flag = true;    
                    }
                    break;
            case 1: if(strstr((*book).Category, sel_value))
                    {
                        sel_flag = true;    
                    }
                    break;
            case 2: if(strstr((*book).BookName, sel_value))
                    {
                        sel_flag = true;    
                    }
                    break;
            case 3: if(strstr((*book).Press, sel_value))
                    {
                        sel_flag = true;    
                    }
                    break;
            case 4: if(strstr((*book).Author, sel_value))
                    {
                        sel_flag = true;    
                    }
                    break;
            case 5: if(strstr((*book).Picture, sel_value))
                    {
                        sel_flag = true;    
                    }
                    break;
        }
        if(sel_flag)
        {
            fout.write((char *)book, sizeof(*book));
            count++;
        }
    }
    fin.close();
    fout.close();
    //write back
    this->copy("./data/book_sel.dat", "./data/book_temp.dat");
    //clear(book_temp.dat)
    //just for saving space
    this->clear("./data/book_temp.dat");
    return count;
}

//for int value
int book_io::select(string attr, int lower_bound, int upper_bound, bool new_flag) const
{
    int index, count = 0;
    bool sel_flag;
    ifstream fin;
    ofstream fout("./data/book_temp.dat", ios_base::binary);
    //generate a string-type table
    string Table[3] = {"Year", "TotalNum", "Inventory"};
    //get index
    for(index = 0; index < 3; index++)
    {
        if(attr == Table[index]) break;
    }
    if(index == 3)
    {
        cout << "ERROR: No such attribute!" << endl;
        return 0;
    }
    //if start a new select
    if(new_flag)
    {
        this->copy("./data/book_sel.dat", "./data/book.dat");
    }
    fin.open("./data/book_sel.dat", ios_base::binary);
    while(fin.read((char *)book, sizeof(*book)))
    {
        sel_flag = false;
        switch(index)
        {
            case 0: if((*book).Year >= lower_bound && (*book).Year <= upper_bound)
                    {
                        sel_flag = true;    
                    }
                    break;
            case 1: if((*book).TotalNum >= lower_bound && (*book).TotalNum <= upper_bound)
                    {
                        sel_flag = true;    
                    }
                    break;
            case 2: if((*book).Inventory >= lower_bound && (*book).Inventory <= upper_bound)
                    {
                        sel_flag = true;    
                    }
                    break;
        }
        if(sel_flag)
        {
            fout.write((char *)book, sizeof(*book));
            count++;
        }
    }
    fin.close();
    fout.close();
    //write back
    this->copy("./data/book_sel.dat", "./data/book_temp.dat");
    //clear(book_temp.dat)
    //just for saving space
    this->clear("./data/book_temp.dat");
    return count;
}

//for double value
int book_io::select(string attr, double lower_bound, double upper_bound, bool new_flag) const
{
    int count = 0;
    bool sel_flag;
    ifstream fin;
    ofstream fout("./data/book_temp.dat", ios_base::binary);
    //if start a new select
    if(new_flag)
    {
        this->copy("./data/book_sel.dat", "./data/book.dat");
    }
    fin.open("./data/book_sel.dat", ios_base::binary);
    if(attr == "Price")
    {
        while(fin.read((char *)book, sizeof(*book)))
        {
            sel_flag = false;
            if((*book).Price >= lower_bound && (*book).Price <= upper_bound)
            {
                sel_flag = true;    
            }
            if(sel_flag)
            {
                fout.write((char *)book, sizeof(*book));
                count++;
            }
        }
    }
    else
    {
        cout << "ERROR: No such attribute!" << endl;
        return 0;
    }

    fin.close();
    fout.close();
    //write back
    this->copy("./data/book_sel.dat", "./data/book_temp.dat");
    //clear(book_temp.dat)
    //just for saving space
    this->clear("./data/book_temp.dat");
    return count;
}

//print the result of select(book_sel.dat)
void book_io::print_sel() const
{
    ifstream fin("./data/book_sel.dat", ios_base::binary);
    
    cout << "BookID\tCategory\tBookName\tPress\tYear\tAuthor\tPrice\tTotalNum\tInventory\tPicture" <<endl;
    while(fin.read((char *)book, sizeof(*book)))
    {
        cout << (*book).BookID << "\t" << (*book).Category << "\t" << (*book).BookName << "\t" << (*book).Press << "\t" << (*book).Year << "\t" 
             << (*book).Author << "\t" << (*book).Price << "\t" << (*book).TotalNum << "\t" << (*book).Inventory << "\t" << (*book).Picture << endl;
    }
    fin.close();
}

bool book_io::print_pic(const char *bookid) const
{
    bool sel_flag = false;
    ifstream fin("./data/book.dat", ios_base::binary);
    //select
    while(fin.read((char *)book, sizeof(*book)))
    {
        if(strcmp((*book).BookID, bookid)==0)
        {
            sel_flag = true;
            break;
        }
    }
    fin.close();
    if(sel_flag)
    {
        //system((*book).Picture);
        return true;
    }
    else
    {
        cout << "No such BookID!!" << endl;
        return false;
    }
}

//insert
bool book_io::insert(const char *bookid, const char *category, const char *bookname, const char *press, int year, const char *author, double price, int totalnum, int inventory, const char *picture) const
{    
    if(!this->select("BookID", bookid, true))
    {
        ofstream fout("./data/book.dat", ios_base::binary|ios_base::app);
        strcpy((*book).BookID, bookid);
        strcpy((*book).Category, category);
        strcpy((*book).BookName, bookname);
        strcpy((*book).Press, press);
        (*book).Year = year;        
        strcpy((*book).Author, author);
        (*book).Price = price;
        (*book).TotalNum = totalnum;
        (*book).Inventory =  inventory;
        strcpy((*book).Picture, picture);

        fout.write((char *)book, sizeof(*book));
        fout.close();   
        return true;
    }
    else
    {
        cout << "ERROR: The BookID has existed!!" << endl;
        return false;
    }
}

//deletion only for primary key
bool book_io::del(const char *bookid) const
{
    ifstream fin("./data/book.dat", ios_base::binary);
    ofstream fout("./data/book_temp.dat", ios_base:: binary);
    //select
    while(fin.read((char *)book, sizeof(*book)))
    {
        if(strcmp((*book).BookID, bookid)!=0)
        {
            fout.write((char *)book, sizeof(*book));
        }
        else
        {
            continue;
        }
    }
    fin.close();
    fout.close();
    //write back
    this->copy("./data/book.dat", "./data/book_temp.dat");
    //clear(book_temp.dat)
    //just for saving space
    this->clear("./data/book_temp.dat");
    return true;
}

//update(select only for primary key)
//for string 
bool book_io::update(const char *bookid, string attr, const char *new_value) const
{
    int index;
    ifstream fin("./data/book.dat", ios_base::binary);
    ofstream fout("./data/book_temp.dat", ios_base:: binary);
    //generate a string-type table
    string Table[5] = {"Category", "BookName", "Press", "Author","Picture"};
    //get index
    for(index = 0; index < 5; index++)
    {
        if(attr == Table[index]) break;
    }
    if(index == 5)
    {
        cout << "ERROR: No such attribute!";
        return false;
    }
    //select
    while(fin.read((char *)book, sizeof(*book)))
    {
        if(strcmp((*book).BookID, bookid)!=0)
        {
            fout.write((char *)book, sizeof(*book));
        }
        else
        {
            switch(index)
            {
                case 0: strcpy((*book).Category, new_value); break;
                case 1: strcpy((*book).BookName, new_value); break;
                case 2: strcpy((*book).Press, new_value); break;
                case 3: strcpy((*book).Author, new_value); break;
                case 4: strcpy((*book).Picture, new_value); break;
            }
            fout.write((char *)book, sizeof(*book));
        }
    }
    fin.close();
    fout.close();
    //write back
    this->copy("./data/book.dat", "./data/book_temp.dat");
    //clear(book_temp.dat)
    //just for saving space
    this->clear("./data/book_temp.dat");
    return true;
}

//for int
bool book_io::update(const char *bookid, string attr, int new_value) const
{
    int index;
    ifstream fin("./data/book.dat", ios_base::binary);
    ofstream fout("./data/book_temp.dat", ios_base:: binary);
    //generate a string-type table
    string Table[3] = {"Year", "TotalNum", "Inventory"};
    //get index
    for(index = 0; index < 3; index++)
    {
        if(attr == Table[index]) break;
    }
    if(index == 3)
    {
        cout << "ERROR: No such attribute!";
        return false;
    }
    //select
    while(fin.read((char *)book, sizeof(*book)))
    {
        if(strcmp((*book).BookID, bookid)!=0)
        {
            fout.write((char *)book, sizeof(*book));
        }
        else
        {
            switch(index)
            {
                case 0: (*book).Year = new_value; break;
                case 1: (*book).TotalNum = new_value; break;
                case 2: (*book).Inventory = new_value; break;
            }
            fout.write((char *)book, sizeof(*book));
        }
    }
    fin.close();
    fout.close();
    //write back
    this->copy("./data/book.dat", "./data/book_temp.dat");
    //clear(book_temp.dat)
    //just for saving space
    this->clear("./data/book_temp.dat");
    return true;
}

//for double
bool book_io::update(const char *bookid, string attr, double new_value) const
{
    ifstream fin("./data/book.dat", ios_base::binary);
    ofstream fout("./data/book_temp.dat", ios_base:: binary);
    if(attr == "Price")
    {
        while(fin.read((char *)book, sizeof(*book)))
        {
            if(strcmp((*book).BookID, bookid)!=0)
            {
                fout.write((char *)book, sizeof(*book));
            }
        else
        {
            (*book).Price = new_value;
            fout.write((char *)book, sizeof(*book));
        }
    }
    fin.close();
    fout.close();
    //write back
    this->copy("./data/book.dat", "./data/book_temp.dat");
    //clear(book_temp.dat)
    //just for saving space
    this->clear("./data/book_temp.dat");
    return true;
    }
    else
    {
        cout << "ERROR: No such attribute!";
        return false;
    }
}
  
//get (only for primary key)
//for string value
//get Category
//return value: category for success, null for fail.
char* book_io::get_Category(const char *bookid) const
{
    if(this->select("BookID", bookid, true))
    {
        ifstream fin("./data/book_sel.dat", ios_base::binary);
        fin.read((char *)book, sizeof(*book));
        fin.close();
        return (*book).Category;
    }
    else
    {
        cout << "ERROR: No such a book!!";
        return NULL;
    }    
}
//get BookName
//return value: bookname for success, null for fail.
char* book_io::get_BookName(const char *bookid) const
{
    if(this->select("BookID", bookid, true))
    {
        ifstream fin("./data/book_sel.dat", ios_base::binary);
        fin.read((char *)book, sizeof(*book));
        fin.close();
        return (*book).BookName;
    }
    else
    {
        cout << "ERROR: No such a book!!";
        return NULL;
    }   
}
//get Press
//return value: press for success, null for fail.
char* book_io::get_Press(const char *bookid) const
{
    if(this->select("BookID", bookid, true))
    {
        ifstream fin("./data/book_sel.dat", ios_base::binary);
        fin.read((char *)book, sizeof(*book));
        fin.close();
        return (*book).Press;
    }
    else
    {
        cout << "ERROR: No such a book!!";
        return NULL;
    }   
}
//get Author
//return value: author for success, null for fail.
char* book_io::get_Author(const char *bookid) const
{
    if(this->select("BookID", bookid, true))
    {
        ifstream fin("./data/book_sel.dat", ios_base::binary);
        fin.read((char *)book, sizeof(*book));
        fin.close();
        return (*book).Author;
    }
    else
    {
        cout << "ERROR: No such a book!!";
        return NULL;
    }   
}
//get Picture(Addr)
//return value: picture(addr) for success, null for fail.
char* book_io::get_Picture(const char *bookid) const
{
    if(this->select("BookID", bookid, true))
    {
        ifstream fin("./data/book_sel.dat", ios_base::binary);
        fin.read((char *)book, sizeof(*book));
        fin.close();
        return (*book).Picture;
    }
    else
    {
        cout << "ERROR: No such a book!!";
        return NULL;
    }   
}

//for int value 
//get Year
//return value: year for success, -1 for fail.
int book_io::get_Year(const char *bookid) const
{
    if(this->select("BookID", bookid, true))
    {
        ifstream fin("./data/book_sel.dat", ios_base::binary);
        fin.read((char *)book, sizeof(*book));
        fin.close();
        return (*book).Year;
    }
    else
    {
        cout << "ERROR: No such a book!!";
        return -1;
    }   
}
//get Inventory
//return value: inventory for success, -1 for fail.
int book_io::get_Inventory(const char *bookid) const
{
    if(this->select("BookID", bookid, true))
    {
        ifstream fin("./data/book_sel.dat", ios_base::binary);
        fin.read((char *)book, sizeof(*book));
        fin.close();
        return (*book).Inventory;
    }
    else
    {
        cout << "ERROR: No such a book!!";
        return -1;
    }   
}
//get TotalNum
//return value: totalnum for success, -1 for fail.
int book_io::get_TotalNum(const char *bookid) const
{
    if(this->select("BookID", bookid, true))
    {
        ifstream fin("./data/book_sel.dat", ios_base::binary);
        fin.read((char *)book, sizeof(*book));
        fin.close();
        return (*book).TotalNum;
    }
    else
    {
        cout << "ERROR: No such a book!!";
        return -1;
    }   
}

//for double value
//get Price
//return value: price for success, -1 for fail.
double book_io::get_Price(const char *bookid) const
{
    if(this->select("BookID", bookid, true))
    {
        ifstream fin("./data/book_sel.dat", ios_base::binary);
        fin.read((char *)book, sizeof(*book));
        fin.close();
        return (*book).Price;
    }
    else
    {
        cout << "ERROR: No such a book!!";
        return -1;
    }   
}


