#ifndef _RECORD_H_
#define _RECORD_H_

#include"datetime.h"
#include<iostream>
#include<vector>
#include<cstring>
#include<fstream>
#include<cstdio>
#include<sstream>
/* class datetime for record using
 * construct destruct check compare update print
 * MORE
 */
class record
{
    char book_id[16];
    char user_id[16];
    char admin_id[16];
    datetime borrow_time;
    datetime return_time;
public:
    record();
    record(const std::string, const std::string, const std::string,
            const datetime, const datetime);
    ~record();
    void save(const std::string target="./data/record.dat")const;//save the block of data into the file. using ios_base::app method.
    void save(std::fstream &)const;//use other fstream to save
    void load(const std::string target="./data/record.dat");//the same as save method
    void load(std::fstream &);
    char *get_bid();
    char *get_uid();
    std::string to_string()const;//formated output string
    void update(const std::string, const std::string, const std::string,
            const datetime, const datetime);
};

class record_io
{
    record data;//store the current record
    int current_pos;//file pointer to current position
    int next_pos;//file pointer to next position
public:
    record_io();
    ~record_io();
    void traverse_out()const;//output all the record
    bool traverse_to_next();//go to the next position
    std::string to_string()const;//formated output string
    bool del_data()const;//delete all the data
    bool filter(const std::string, const std::string);
    bool filter(const std::string);
    void update(const std::string, const std::string,
            const std::string, const datetime, const datetime);
    void del(const std::string, const std::string);
    bool append(const std::string, const std::string, const std::string,
            const datetime, const datetime);//insert a new record to the end of data
    record get_data()const ;
};

#endif
