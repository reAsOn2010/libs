#ifndef NODE_H
#define NODE_H
#include"c_person.h"
class node{
public:
	 person x;
	node* next;
};
#endif