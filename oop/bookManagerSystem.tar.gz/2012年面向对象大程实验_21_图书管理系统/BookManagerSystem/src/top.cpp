#include "top.h"

using namespace std;

int main()
{
    //pc c;
    //person admin("admin","123456", 1, 1, 0, 1);
    //c.insert(admin);

    booksys sys;
    sys.run();
    return 0;
}
