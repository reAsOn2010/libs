#ifndef _BOOKSYS_H_
#define _BOOKSYS_H_

#include<iostream>
#include<string>
#include<fstream>
#include<cstdlib>
#include"record.h"
#include"book.h"
#include"pc.h"

using namespace std;
class booksys
{

    record_io r_io;
    book_io b_io;
    pc p_io;
    
    string u_id;
    string u_pw;
    bool super_user;
    bool logined;
    int func_id;
    bool exit_flag;
public:
    booksys();
    ~booksys();
    void run();
    void welcome();
    void login();
    void func_choose();
    void function();
    void search_book();
    void borrowed_book();
    void add_book();
    void del_book();
    void add_user();
    void del_user();
    void borrow_book();
    void return_book();
    void logout();
    void exit_all();
};

#endif
