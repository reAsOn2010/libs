#include "record.h"
#include "datetime.h"

/*
 * because the record would be save into a binary file
 * so all the string type I use the char array to replace
 */
record::record()
{
    //initialize
    book_id[0] = '\0';
    user_id[0] = '\0';
    admin_id[0] = '\0';
}

record::record(const std::string b_id, const std::string u_id, const std::string a_id,
        const datetime b_time, const datetime r_time)
{
    strcpy(book_id, b_id.c_str());
    strcpy(user_id, u_id.c_str());
    strcpy(admin_id, a_id.c_str());
    borrow_time = b_time;
    return_time = r_time;
}

record::~record()
{
}

std::string record::to_string()const
{
    char temp[100];
    //formated output into such a string
    sprintf(temp, "Book ID: %s\nUser ID: %s\nAdmin ID: %s\n", book_id, user_id, admin_id);
    std::string ret(temp);
    ret += "Borrow Time: " + borrow_time.to_string() + "\n" + "Return Time: " + return_time.to_string();
    return ret;
}

void record::save(const std::string target)const
{
    std::fstream os;
    //use ios_base::app to add to the end of file
    os.open(target.c_str(), std::ios_base::out|std::ios_base::app|std::ios_base::binary);
    if(os.is_open()){
        os.write((char*)this, sizeof(record));
    }
    else
    {
    }
    os.close();
}

void record::save(std::fstream &os)const
{
    if(os.is_open())
    {
        os.write((char*)this, sizeof(record));
    }
}

void record::load(const std::string target)
{
    std::fstream is;
    is.open(target.c_str(), std::ios_base::in|std::ios_base::binary);
    if(is.is_open()){
        is.read((char*)this, sizeof(record));
    }
    else
    {
    }
    is.close();
}

void record::load(std::fstream &is)
{
    if(is.is_open()){
        is.read((char*)this, sizeof(record));
    }
    else
    {
    }
}

char * record::get_bid()
{
    return book_id;
}

char * record::get_uid()
{
    return user_id;
}


void record::update(const std::string b_id, const std::string u_id,
       const std::string a_id, const datetime b_time, const datetime r_time)
{
    strcpy(book_id, b_id.c_str());
    strcpy(user_id, u_id.c_str());
    strcpy(admin_id, a_id.c_str());
    borrow_time = b_time;
    return_time = r_time;
}

/* record_io's operations */
record_io::record_io()
{
    data = record();
    current_pos = 0;
    next_pos = 0;
}

record_io::~record_io()
{
}

void record_io::traverse_out()const
{
    record temp;
    std::fstream is;
    is.open("./data/record.dat", std::ios_base::in|std::ios_base::binary);
    is.seekg(0);
    //is.peek() is to check EOF flag
    //it is both ok in windows and linux
    while(is.is_open() && is.peek() != EOF){
        temp.load(is);
        std::cout << temp.to_string() << std::endl;
    }
    is.close();
}

bool record_io::traverse_to_next()
{
    std::fstream is;
    is.open("./data/record.dat", std::ios_base::in|std::ios_base::binary);
    if(is.is_open() && is.peek() != EOF){
        is.seekg(next_pos);
        //is.seekp(current_pos);
        current_pos = next_pos;
        data.load(is);
        next_pos = is.tellp();
    }
    //following if statement is to keep the pointer recurring
    if(is.peek() == EOF)
    {
        next_pos = 0;
        return false;
    }
    is.close();
    return true;
}

std::string record_io::to_string()const
{
    //formated output
    std::stringstream ss;
    std::string temp;
    ss << next_pos;
    ss >> temp;
    std::stringstream ss2;
    std::string temp2;
    ss2 << current_pos;
    ss2 >> temp2;
    //return data.to_string() + "\nnext positon: " + temp;
    return data.to_string() + "\ncurrent positon:"+ temp2 +
        "\nnext positon: " + temp;
}

bool record_io::filter(const std::string u_id)
{
    //temporarily change the pointer
    //to make sure that all records would be checked
    int stack_current = current_pos;
    int stack_next = next_pos;
    current_pos = 0;
    next_pos = 0;

    do{
        traverse_to_next();
        if(u_id.compare(data.get_uid()) == 0)
        {
            std::cout << to_string() << std::endl;
        }
    }while(next_pos != 0);
    //restore the file pointer
    current_pos = stack_current;
    next_pos = stack_next;
    return false;
}

bool record_io::filter(const std::string b_id, const std::string u_id)
{
    int stack_current = current_pos;
    int stack_next = next_pos;
    current_pos = 0;
    next_pos = 0;

    do{
        traverse_to_next();
        if(b_id.compare(data.get_bid()) == 0 && u_id.compare(data.get_uid()) == 0)
        {
            return true;
        }
    }while(next_pos != 0);
    current_pos = stack_current;
    next_pos = stack_next;
    return false;
}

bool record_io::del_data()const
{
/* remove example: remove myfile.txt */
    if( remove( "./data/record.dat" ) != 0 )
        return false;
    else
        return true;
}

void record_io::update(const std::string b_id, const std::string u_id, 
        const std::string a_id, const datetime b_time, const datetime r_time)
{
    data.update(b_id, u_id, a_id, b_time, r_time);
    std::fstream os;
    //use ios_base::in and ios_base::out to keep original data
    os.open("./data/record.dat", std::ios_base::out|std::ios_base::in|std::ios_base::binary);
    os.seekp(current_pos);
    if(os.is_open()){
        data.save(os);
    }
    os.close();
}

void record_io::del(const std::string b_id, const std::string u_id)
{
    //create a new data file
    //if data is not the one to delete
    //put it into the new file
    //at last   rename the new file
    current_pos = 0;
    next_pos = 0;
    int i = 0;
    do{
        traverse_to_next();
        if(b_id.compare(data.get_bid()) == 0 && u_id.compare(data.get_uid()) == 0)
        {
        }
        else{
            data.save("./data/record_temp.dat");
            i++;
        }
        i++;
    }while(next_pos != 0);
    if(i == 1){
        std::fstream os;
        os.open("./data/record_temp.dat", std::ios_base::out|std::ios_base::app|std::ios_base::binary);
    }
    current_pos = 0;
    next_pos = 0;
    rename("./data/record_temp.dat", "./data/record.dat");
    traverse_to_next();
}

bool record_io::append(const std::string b_id,const  std::string u_id,
        const std::string a_id, const datetime b_time, const datetime r_time)
{
    if(!filter(b_id, u_id)){
        data = record(b_id, u_id, a_id, b_time, r_time);
        data.save();
        return true;
    }
    else
        return false;
}

record record_io::get_data()const
{
    return data;
}
